<?php 
/*
* Template Name:Casestudies Template
  Template Post Type: knowledge 
*/

get_header();
?>
<?php 
$post_id = get_the_ID();

if (function_exists('get_field')) {
	$heading = get_field('heading');
	//$mast_sel_modules = get_field('mast_sel_modules');
    $mast_add_module = get_field('mast_add_module');
}

?>
<?php if (get_field('enable_banner')): ?>
<div class="page-hero section bg-lightgrey">
	<div class="wrapper">
		<div class="module-wrapper">
			<div class="title-holder">
				<?php if ($heading != ""): ?>
				<h3 class="subtitle"><?php echo $heading; ?></h3>
				<?php endif; ?>
				<h1 class="page-title"><?php echo get_the_title(); ?></h1>
			</div>
			<div class="caption-holder">
				<?php the_excerpt();?>
			</div>
		</div>
	</div>
</div>
<?php endif; ?>


<!--  Partner Logo Section -->
<?php echo Partner_Logos_Fn(get_the_ID()); ?>
<!--  Contact Form Section -->
<?php echo Contact_Form_Fn(get_the_ID()); ?>

<?php get_footer(); ?>