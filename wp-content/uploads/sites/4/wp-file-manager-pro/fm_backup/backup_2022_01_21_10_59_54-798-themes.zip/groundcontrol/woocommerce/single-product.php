<?php
/**
 * The Template for displaying all single products
 *
 * This template can be overridden by copying it to yourtheme/woocommerce/single-product.php.
 *
 * HOWEVER, on occasion WooCommerce will need to update template files and you
 * (the theme developer) will need to copy the new files to your theme to
 * maintain compatibility. We try to do this as little as possible, but it does
 * happen. When this occurs the version of the template file will be bumped and
 * the readme will list any important changes.
 *
 * @see         https://docs.woocommerce.com/document/template-structure/
 * @package     WooCommerce\Templates
 * @version     1.6.4
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit; // Exit if accessed directly
}

get_header(); ?>
<?php $product = wc_get_product( $post->ID ); ?>
<?php if( have_rows('top_bar_cta') ): ?>
   <?php while(have_rows('top_bar_cta')): the_row();?>
        <div class="product-nav-top section">
            <div class="wrapper">
                <div class="product-nav-inner">
                    <div class="menu-container">
                        <?php $y = 1; ?>
                        <?php while( have_rows('menu') ) : the_row(); ?>
                            <a <?php if($y == 1):?>class="active"<?php endif;?> href="#section<?php echo get_sub_field('page_module_order_number');?>"><?php the_sub_field('title');?></a>
                        <?php $y++; endwhile;?>
                    </div>
                    <div class="media-container">
                        <?php 
                            while(have_rows('links')): the_row();
                                switch(get_sub_field('link_type')){
                                    case 'link':
                                        $link = get_sub_field('link');
                                        echo '<a class="link '.get_sub_field('colour').'" href="'.$link['url'].'" target="'.$link['target'].'">'.$link['title'].'</a>';
                                        break;
                                    case 'file':
                                        echo '<a class="file-download '.get_sub_field('colour').'" href="'.get_sub_field('file').'">'.get_sub_field('file_button_title').'</a>';
                                        break;
                                    case 'contact':
                                        echo '<a class="contact '.get_sub_field('colour').'" href="#">'.get_sub_field('form_button_title').'</a>';
                                        $contact_modal = [];
                                        $contact_modal['enabled'] = true;
                                        $contact_modal['id'] = get_sub_field('form_id');
                                        break;
                                    default:
                                        break;
                                }  
                            endwhile; 
                        ?>
                    </div>
                </div>
            </div>
        </div>
    <?php endwhile;?>
<?php endif;?>
<section class="section">
	<?php
		/**
		 * woocommerce_before_main_content hook.
		 *
		 * @hooked woocommerce_output_content_wrapper - 10 (outputs opening divs for the content)
		 * @hooked woocommerce_breadcrumb - 20
		 */
		do_action( 'woocommerce_before_main_content' );
	?>
    <div class="wrapper">
        <?php wc_print_notices(); ?>
        <div class="product page-module" id="section0">
            <div class="product-gallery">
                <div class="featured-image-container">
                    <div class="featured-slick">
                    <?php while(have_rows('product_image')): the_row(); ?>
                            <?php
                            $images = get_sub_field('product_gallery');
                            $size = 'full'; // (thumbnail, medium, large, full or custom size)
                            if($images){ ?>
                                <?php $imageid = 0; ?>
                                <?php foreach( $images as $image_id ): ?>
                                    <?php $imageid++;?>
                                    <div class="single-image not-shown" data-imageid="<?=$imageid;?>">
                                        <img  src="<?=$image_id['url'];?>"/>
                                        <?php if($image_id['caption']){ ?>
                                        <div class="caption">
                                            <div class="caption-marker">i</div>
                                            <div class="caption-content"><p><?=filter_var($image_id['caption'], FILTER_SANITIZE_STRING);?></p></div>
                                        </div>
                                        <?php } ?>
                                    </div>
                                    <?php endforeach; ?>
                            <?php }else{ ?>
                                <div class="single-image-placeholder">
                                    <img src="<?=get_field('default_product_image', 'option');?>" alt="">
                                </div>
                            <?php } ?>
                        </div>
                            <div class="slick-action">
                                <button class="slick-next-c"></button>
                                <button class="slick-prev-c"></button>
                            </div>
                    </div>
                    <div class="image-scroll">
                    <?php
                        $images = get_sub_field('product_gallery');
                        $size = 'full'; // (thumbnail, medium, large, full or custom size)
                        if( $images ): ?>
                            <?php $imageid = 0; ?>
                            <?php foreach( $images as $image_id ): ?>
                                <?php $imageid++;?>
                                <span class="single-image" data-imageid="<?=$imageid;?>">
                                    <img src="<?=$image_id['url'];?>"/>
                                </span>
                                <?php endforeach; ?>
                        <?php endif; ?>
                    </div>
                <?php endwhile; ?>
            </div>
            <div class="product-information<?php  if ( $product->is_type( 'variable' ) ) { echo ' variable'; }?>">
                <h1 class="product-title"><?=get_the_title();?></h1>
                <?php /* <span class="price"><bdi><?=$product->get_price_html(); ?></bdi></span> */?>
                <?php while(have_rows('product_content')): the_row(); ?>
                    <?php $buy_outright = false; $additional_link = ''; ?>
                    <?php // Get price if enabled, if not get the enquiry options ?>
                    <?php while(have_rows('options')): the_row();?>
                            <?php 
                                if(get_sub_field('buying_options') == 'buy-now'){ 
                                    $buy_outright = true;
                                    if(get_sub_field('additional_cta')){
                                        $additional_link = get_sub_field('link');
                                    }
                            ?>
                                <?php 
		                            do_action( 'woocommerce_single_product_summary' ); ?>
                                    <?php /*<a class="add-to-cart btn btn-lightgreen" href="<?=$product->add_to_cart_url()?>">Add To Cart</a>*/ ?>
                            <?php 
                                }elseif(get_sub_field('buying_options') == 'buy-and-enquire'){
                                    $buy_outright = true; $enable_enquire = true;
                                    $enquiry_form = get_sub_field('enquiry_form');
                                    if(get_sub_field('additional_cta')){
                                        $additional_link = get_sub_field('link');
                                    }
		                            do_action( 'woocommerce_single_product_summary' ); 
                                }else{
                                    $buy_outright = false;
                                    $enquiry_form = get_sub_field('enquiry_form');
                                    if(get_sub_field('additional_cta')){
                                        $additional_link = get_sub_field('link');
                                    }
                                } 
                            ?>
                    <?php endwhile; ?>
                    <div class="product-description">
                        <?=get_sub_field('product_description');?>
                    </div>
                    <?php if($buy_outright == false){ ?>
                        <button class="enquiry">Enquire</button>
                        <?php if($additional_link){ ?>
                        <a class="additional-link" href="<?=$additional_link['url'];?>" target="<?=$additional_link['target'];?>"><?=$additional_link['title'];?></a>
                        <?php } ?>
                    <?php 
                    }elseif($enable_enquire == true){ ?>
                        <button id="buyEnquire" class="enquiry">Enquire</button>
                        <script>jQuery(document).ready(function($){ $('#buyEnquire').appendTo('form.cart'); $('#buyEnquire').css('display', 'block'); });</script>
                        <?php if($additional_link){?>
                        <a class="additional-link" href="<?=$additional_link['url'];?>" target="<?=$additional_link['target'];?>"><?=$additional_link['title'];?></a>
                        <?php
                        }
                    }else{
                        if($additional_link){
                        ?>
                        <a class="additional-link" href="<?=$additional_link['url'];?>" target="<?=$additional_link['target'];?>"><?=$additional_link['title'];?></a>
                        <?php
                        }
                    } ?>
                <?php endwhile; ?>
                <?php // Pull price through if enabled ?>
            </div>
        </div>
    </div>
    <?php $x = 1;?>
      <?php while(have_rows('modules')): the_row(); ?>
        <?php $args = array(
          'order'  => $x,
        )?>
        <?php $layout = get_row_layout(); ?>
        <?php get_template_part('template-parts/page-modules/'.$layout,'',$args); ?>
    <?php $x++; endwhile; ?>

	<?php
		/**
		 * woocommerce_after_main_content hook.
		 *
		 * @hooked woocommerce_output_content_wrapper_end - 10 (outputs closing divs for the content)
		 */
		do_action( 'woocommerce_after_main_content' );
	?>
</section>
    <?php 
    $accessories = $product->get_upsell_ids();
    if($accessories){
        ?>
<section class="accessories-products section" id="section999998">
    <div class="wrapper">
        <h3>Accessories</h3>
        <div class="products-container"><?php
        foreach($accessories as $id => $apost){
            $product = wc_get_product($apost);
            ?>
                <div class="single-product" data-mh="product-cards-accessories">
                    <a href='<?php the_permalink($apost); ?>'>
                        <div class="image-container">
                            <?php
                            while(have_rows('product_image', $apost)): the_row();
                                $gallery = get_sub_field('product_gallery'); 
                                if($gallery){
                                    echo '<div data-mh="product-thumbnails" class="product-thumb">';
                                    echo '<img data-type="product" data-mh="product-thumbnails-accessories-image" src="'.$gallery[0]['url'].'"/>';
                                    echo '</div>';
                                }else{
                                    echo '<div data-mh="product-thumbnails" class="product-thumb">';
                                    echo '<img data-type="default" data-mh="product-thumbnails-accessories-image" src="'.get_field('default_product_image', 'option').'"/>';
                                    echo '</div>';
                                }
                            endwhile; 
                            ?>
                        </div>
                        <div class="content-container">
                            <h4 data-mh="related-product-title"><?php echo get_the_title($apost); ?></h4>
                            <?php
                                echo '<p>'.$product->get_price_html().'</p>';
                            ?>
                        </div>
                    </a>
                </div> 
            <?php
        } 
        ?>
    </div>
</section>
<?php } ?>
<?php 
    $crosssells = get_post_meta( get_the_ID(), '_crosssell_ids' ); 
    if(count($crosssells)>0){
?>
<section class="related-products section" id="section999999">
    <div class="wrapper">
    <?php
        $crosssells = $crosssells[0];
        if(count($crosssells)>0){ ?>
            <h3>Related Products</h3>
            <div class="products-container">
                <?php
                $args = array( 'post_type' => 'product', 'posts_per_page' => 10, 'post__in' => $crosssells );
                $loop = new WP_Query( $args );
                while ( $loop->have_posts() ) : $loop->the_post();?>
                <div class="single-product" data-mh="related-products-single">
                    <a href='<?php the_permalink(); ?>'>
                        <div class="image-container">
                            <?php
                            while(have_rows('product_image')): the_row();
                                $gallery = get_sub_field('product_gallery'); 
                                if($gallery){
                                    echo '<div data-mh="product-thumbnails" class="product-thumb">';
                                    echo '<img data-type="product" src="'.$gallery[0]['url'].'"/>';
                                    echo '</div>';
                                }else{
                                    echo '<div data-mh="product-thumbnails" class="product-thumb">';
                                    echo '<img data-type="default" src="'.get_field('default_product_image', 'option').'"/>';
                                    echo '</div>';
                                }
                            endwhile; 
                            ?>
                        </div>
                        <div class="content-container">
                            <h4 data-mh="related-product-title"><?php echo get_the_title(); ?></h4>
                            <?php
                                $temp_product = wc_get_product(get_the_id());
                                echo '<p>'.$temp_product->get_price_html().'</p>';
                            ?>
                        </div>
                    </a>
                </div> 
            <?php endwhile; ?>
            </div>
    <?php } ?>
    </div>
</section>
<?php } ?>
<section class="footer-module horizontal-logos section">
    <div class="wrapper">
        <div class="inner">
            <?php 
            $images = get_field('partner_logos', 'option');
            $size = 'full'; // (thumbnail, medium, large, full or custom size)
            if( $images ): ?>
                <?php foreach( $images as $image_id ): ?>
                    <div class="logo">
                        <img src="<?=$image_id;?>"/>
                    </div>
                <?php endforeach; ?>
            <?php endif; ?>
        </div>
    </div>
</section>
<?php while(have_rows('contact_form', 'option')): the_row(); ?>
    <section class="footer-module contact-form section bg-lightblue">
        <div class="wrapper">
            <div class="content-section">
                    <h3><?=get_sub_field('title');?></h3>
                    <p><?=get_sub_field('content');?></p>
            </div>
            <div class="contact-section">
                <?php echo do_shortcode('[gravityform id="'.get_sub_field('form_id').'" ajax="true"]');?>
            </div>
        </div>
    </section>
<?php endwhile; ?>
<div class="modal product-module-modal product-enquire">
    <div class="modal-wrapper">
        <span class="close" id="closeProductModuleModal"></span>
                <?php if($enquiry_form){ ?>
                    <span data-formid="<?=$enquiry_form;?>"></span>
                    <?php echo do_shortcode('[gravityform id="'.$enquiry_form.'" ajax="true"]');?>
                <?php }else{ ?>
                    <?php echo do_shortcode('[gravityform id="'.get_field('gravity_forms_fallback_form', 'option').'" ajax="true"]');?>
                <?php } ?>
    </div>
</div>
<?php if(isset($contact_modal)){ ?>
    <div class="modal contact-enquire contact-enquire-product-modal">
    <div class="modal-wrapper">
        <span class="close" id="closeContactEnquireModal"></span>
        <span data-formid="<?=$contact_modal['id'];?>"></span>
        <?php echo do_shortcode('[gravityform id="'.$contact_modal['id'].'" ajax="true"]');?>
    </div>
</div>
<?php }?>
<?php
get_footer();

/* Omit closing php tag at the end of php files to avoid "headers already sent" issues. */