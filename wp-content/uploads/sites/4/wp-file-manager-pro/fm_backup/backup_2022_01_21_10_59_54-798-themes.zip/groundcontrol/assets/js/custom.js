jQuery( document ).ready(function() {
  jQuery(".lower-menu h2 .arrow").click(function(){
      if(jQuery(this).next(".submenu").is(":visible")){
        jQuery(this).next(".submenu").slideUp();
        jQuery("h2").removeClass("active");
      }
      else
      {
        jQuery(".lower-menu h2").removeClass("active");
        jQuery(this).parent("h2").addClass("active");
        jQuery(".lower-menu h2 .submenu").slideUp();
        jQuery(this).next(".submenu").slideDown();
      }
  });

  jQuery('.mobile-trigger').click(function(){
    jQuery("body").toggleClass('menu-open');
  });
  
  jQuery('body.blog .template-inner .posts a.single-post').matchHeight();
  
});