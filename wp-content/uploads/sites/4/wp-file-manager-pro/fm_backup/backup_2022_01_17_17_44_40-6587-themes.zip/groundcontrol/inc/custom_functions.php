<?php 
// Adding Theme  Options to Custom Fields Options
function grod_acf_options_page_settings($settings) {
    $settings['title'] = __('Theme Option','acf');
    $settings['menu'] = __('Theme Option','acf');
    $settings['pages'] = array('General Setting','Partner Logos Setting');

    return $settings;
}
add_filter('acf/options_page/settings', 'grod_acf_options_page_settings');

function grod_resgister_post_init() {
   
   /* Market Custom Post Type */ 

    $lbl_mkt = array(
        'name'                  => _x( 'Markets Pages', 'Post type general name', 'twentytwenty' ),
        'singular_name'         => _x( 'Market', 'Post type singular name', 'twentytwenty' ),
        'menu_name'             => _x( 'Markets Pages', 'Admin Menu text', 'twentytwenty' ),
        'name_admin_bar'        => _x( 'Markets', 'Add New on Toolbar', 'twentytwenty' ),
        'add_new'               => __( 'Add New', 'twentytwenty' ),
        'add_new_item'          => __( 'Add New Market', 'twentytwenty' ),
        'new_item'              => __( 'New Market', 'twentytwenty' ),
        'edit_item'             => __( 'Edit Market', 'twentytwenty' ),
        'view_item'             => __( 'View Market', 'twentytwenty' ),
        'all_items'             => __( 'All Market', 'twentytwenty' ),
        'search_items'          => __( 'Search Markets', 'twentytwenty' ),
        'parent_item_colon'     => __( 'Parent Markets:', 'twentytwenty' ),
        'not_found'             => __( 'No markets found.', 'twentytwenty' ),
        'not_found_in_trash'    => __( 'No markets found in Trash.', 'twentytwenty' ),
       
    );     
    $args_mkt = array(
        'labels'             => $lbl_mkt,
        'description'        => 'Markets',
        'public'             => true,
        'publicly_queryable' => true,
        'show_ui'            => true,
        'show_in_menu'       => true,
        'query_var'          => true,
        'rewrite'            => array( 'slug' => 'markets/%markets_cat%' ),
        'capability_type'    => 'post',
        'has_archive'        => false,
        'hierarchical'       => false,
        'menu_position'      => 20,
        'supports'           => array( 'title', 'editor', 'author', 'thumbnail' ),
        'show_in_rest'       => true
    );
      
    register_post_type( 'markets', $args_mkt );

    $lbl_mkt_cat = array(
        'name'                       => _x( 'Markets Category', 'taxonomy general name', 'twentytwenty' ),
        'singular_name'              => _x( 'Market Category', 'taxonomy singular name', 'twentytwenty' ),
        'search_items'               => __( 'Search Markets Category', 'twentytwenty' ),
        'popular_items'              => __( 'Popular Markets Category', 'twentytwenty' ),
        'all_items'                  => __( 'All Markets Category', 'twentytwenty' ),
        'parent_item'                => null,
        'parent_item_colon'          => null,
        'edit_item'                  => __( 'Edit Market Category', 'twentytwenty' ),
        'update_item'                => __( 'Update Market Category', 'twentytwenty' ),
        'add_new_item'               => __( 'Add New Markets Category', 'twentytwenty' ),
        'new_item_name'              => __( 'New Markets Category Name', 'twentytwenty' ),
        'separate_items_with_commas' => __( 'Separate markets category with commas', 'twentytwenty' ),
        'add_or_remove_items'        => __( 'Add or remove markets category', 'twentytwenty' ),
        'not_found'                  => __( 'No markets category found.', 'twentytwenty' ),
        'menu_name'                  => __( 'Markets Category', 'twentytwenty' ),
    );
 
    $args_mkt_cat = array(
        'hierarchical'          => true,
        'labels'                => $lbl_mkt_cat,
        'show_ui'               => true,
        'show_admin_column'     => true,
        'update_count_callback' => '_update_post_term_count',
        'query_var'             => true,
        'rewrite'               => array( 'slug' => 'markets_cat' ),
    );
 
    register_taxonomy( 'markets_cat', 'markets', $args_mkt_cat );

    /* Solutions Custom Post Type */ 
    $lbl_sol = array(
        'name'                  => _x( 'Solutions Pages', 'Post type general name', 'twentytwenty' ),
        'singular_name'         => _x( 'Solution', 'Post type singular name', 'twentytwenty' ),
        'menu_name'             => _x( 'Solutions Pages', 'Admin Menu text', 'twentytwenty' ),
        'name_admin_bar'        => _x( 'Solutions', 'Add New on Toolbar', 'twentytwenty' ),
        'add_new'               => __( 'Add New', 'twentytwenty' ),
        'add_new_item'          => __( 'Add New Solution', 'twentytwenty' ),
        'new_item'              => __( 'New Solution', 'twentytwenty' ),
        'edit_item'             => __( 'Edit Solution', 'twentytwenty' ),
        'view_item'             => __( 'View Solution', 'twentytwenty' ),
        'all_items'             => __( 'All Solution', 'twentytwenty' ),
        'search_items'          => __( 'Search Solution', 'twentytwenty' ),
        'parent_item_colon'     => __( 'Parent Solution:', 'twentytwenty' ),
        'not_found'             => __( 'No solutions found.', 'twentytwenty' ),
        'not_found_in_trash'    => __( 'No solutions found in Trash.', 'twentytwenty' ),
       
    );     
    $args_sol = array(
        'labels'             => $lbl_sol,
        'description'        => 'Solutions',
        'public'             => true,
        'publicly_queryable' => true,
        'show_ui'            => true,
        'show_in_menu'       => true,
        'query_var'          => true,
        'rewrite'            => array( 'slug' => 'solutions/%solutions_cat%' ),
        'capability_type'    => 'post',
        'has_archive'        => false,
        'hierarchical'       => false,
        'menu_position'      => 20,
        'supports'           => array( 'title', 'editor', 'author', 'thumbnail' ),
        'show_in_rest'       => true
    );
      
    register_post_type( 'solutions', $args_sol );


    $lbl_sol_cat = array(
        'name'                       => _x( 'Solutions Category', 'taxonomy general name', 'twentytwenty' ),
        'singular_name'              => _x( 'Solution Category', 'taxonomy singular name', 'twentytwenty' ),
        'search_items'               => __( 'Search Solutions Category', 'twentytwenty' ),
        'popular_items'              => __( 'Popular Solutions Category', 'twentytwenty' ),
        'all_items'                  => __( 'All Solutions Category', 'twentytwenty' ),
        'parent_item'                => null,
        'parent_item_colon'          => null,
        'edit_item'                  => __( 'Edit Solution Category', 'twentytwenty' ),
        'update_item'                => __( 'Update Solution Category', 'twentytwenty' ),
        'add_new_item'               => __( 'Add New Solution Category', 'twentytwenty' ),
        'new_item_name'              => __( 'New Solutions Category Name', 'twentytwenty' ),
        'separate_items_with_commas' => __( 'Separate solutions category with commas', 'twentytwenty' ),
        'add_or_remove_items'        => __( 'Add or remove solutions category', 'twentytwenty' ),
        'not_found'                  => __( 'No solutions category found.', 'twentytwenty' ),
        'menu_name'                  => __( 'Solutions Category', 'twentytwenty' ),
    );
 
    $args_sol_cat = array(
        'hierarchical'          => true,
        'labels'                => $lbl_sol_cat,
        'show_ui'               => true,
        'show_admin_column'     => true,
        'update_count_callback' => '_update_post_term_count',
        'query_var'             => true,
        'rewrite'               => array( 'slug' => 'solutions_cat' ),
    );
 
    register_taxonomy( 'solutions_cat', 'solutions', $args_sol_cat );


    /* Products Custom Post Type */ 

    $lbl_prod = array(
        'name'                  => _x( 'Products Pages', 'Post type general name', 'twentytwenty' ),
        'singular_name'         => _x( 'Products', 'Post type singular name', 'twentytwenty' ),
        'menu_name'             => _x( 'Products Pages', 'Admin Menu text', 'twentytwenty' ),
        'name_admin_bar'        => _x( 'Products', 'Add New on Toolbar', 'twentytwenty' ),
        'add_new'               => __( 'Add New', 'twentytwenty' ),
        'add_new_item'          => __( 'Add New Products', 'twentytwenty' ),
        'new_item'              => __( 'New Products', 'twentytwenty' ),
        'edit_item'             => __( 'Edit Products', 'twentytwenty' ),
        'view_item'             => __( 'View Products', 'twentytwenty' ),
        'all_items'             => __( 'All Products', 'twentytwenty' ),
        'search_items'          => __( 'Search Products', 'twentytwenty' ),
        'parent_item_colon'     => __( 'Parent Products:', 'twentytwenty' ),
        'not_found'             => __( 'No Products found.', 'twentytwenty' ),
        'not_found_in_trash'    => __( 'No Products found in Trash.', 'twentytwenty' ),
       
    );     
    $args_prod = array(
        'labels'             => $lbl_prod,
        'description'        => 'Products',
        'public'             => true,
        'publicly_queryable' => true,
        'show_ui'            => true,
        'show_in_menu'       => true,
        'query_var'          => true,
        'rewrite'            => array( 'slug' => 'products/%products_cat%' ),
        'capability_type'    => 'post',
        'has_archive'        => false,
        'hierarchical'       => false,
        'menu_position'      => 20,
        'supports'           => array( 'title', 'editor', 'author', 'thumbnail' ),
        'show_in_rest'       => true
    );
      
    register_post_type( 'products', $args_prod );

    $lbl_prod_cat = array(
        'name'                       => _x( 'Products Category', 'taxonomy general name', 'twentytwenty' ),
        'singular_name'              => _x( 'Products Category', 'taxonomy singular name', 'twentytwenty' ),
        'search_items'               => __( 'Search Products Category', 'twentytwenty' ),
        'popular_items'              => __( 'Popular Products Category', 'twentytwenty' ),
        'all_items'                  => __( 'All Products Category', 'twentytwenty' ),
        'parent_item'                => null,
        'parent_item_colon'          => null,
        'edit_item'                  => __( 'Edit Products Category', 'twentytwenty' ),
        'update_item'                => __( 'Update Products Category', 'twentytwenty' ),
        'add_new_item'               => __( 'Add New Products Category', 'twentytwenty' ),
        'new_item_name'              => __( 'New Products Category Name', 'twentytwenty' ),
        'separate_items_with_commas' => __( 'Separate products category with commas', 'twentytwenty' ),
        'add_or_remove_items'        => __( 'Add or remove products category', 'twentytwenty' ),
        'not_found'                  => __( 'No products category found.', 'twentytwenty' ),
        'menu_name'                  => __( 'products Category', 'twentytwenty' ),
    );
 
    $args_prod_cat = array(
        'hierarchical'          => true,
        'labels'                => $lbl_prod_cat,
        'show_ui'               => true,
        'show_admin_column'     => true,
        'update_count_callback' => '_update_post_term_count',
        'query_var'             => true,
        'rewrite'               => array( 'slug' => 'products_cat' ),
    );
 
    register_taxonomy( 'products_cat', 'products', $args_prod_cat );


    /* Knowledge Custom Post Type */
    $lbl_knwl = array(
        'name'                  => _x( 'Knowledge Pages', 'Post type general name', 'twentytwenty' ),
        'singular_name'         => _x( 'Knowledge', 'Post type singular name', 'twentytwenty' ),
        'menu_name'             => _x( 'Knowledge Pages', 'Admin Menu text', 'twentytwenty' ),
        'name_admin_bar'        => _x( 'Knowledge', 'Add New on Toolbar', 'twentytwenty' ),
        'add_new'               => __( 'Add Knowledge', 'twentytwenty' ),
        'add_new_item'          => __( 'Add New Knowledge', 'twentytwenty' ),
        'new_item'              => __( 'New Knowledge', 'twentytwenty' ),
        'edit_item'             => __( 'Edit Knowledge', 'twentytwenty' ),
        'view_item'             => __( 'View Knowledge', 'twentytwenty' ),
        'all_items'             => __( 'All Knowledge', 'twentytwenty' ),
        'search_items'          => __( 'Search Knowledge', 'twentytwenty' ),
        'parent_item_colon'     => __( 'Parent Knowledge:', 'twentytwenty' ),
        'not_found'             => __( 'No knowledge found.', 'twentytwenty' ),
        'not_found_in_trash'    => __( 'No knowledge found in Trash.', 'twentytwenty' ),
       
    );     
    $args_knwl = array(
        'labels'             => $lbl_knwl,
        'description'        => 'Knowledge',
        'public'             => true,
        'publicly_queryable' => true,
        'show_ui'            => true,
        'show_in_menu'       => true,
        'query_var'          => true,
        'rewrite'            => array( 'slug' => 'knowledge' ),
        'capability_type'    => 'post',
        'has_archive'        => false,
        'hierarchical'       => true,
        'menu_position'      => 20,
        'supports'           => array( 'title', 'editor', 'author', 'thumbnail','page-attributes','excerpt' ),
        'show_in_rest'       => true
    );
      
    register_post_type( 'knowledge', $args_knwl );

    $lbl_knwl_cat = array(
        'name'                       => _x( 'knowledge Category', 'taxonomy general name', 'twentytwenty' ),
        'singular_name'              => _x( 'knowledge Category', 'taxonomy singular name', 'twentytwenty' ),
        'search_items'               => __( 'Search knowledge Category', 'twentytwenty' ),
        'popular_items'              => __( 'Popular knowledge Category', 'twentytwenty' ),
        'all_items'                  => __( 'All knowledge Category', 'twentytwenty' ),
        'parent_item'                => null,
        'parent_item_colon'          => null,
        'edit_item'                  => __( 'Edit knowledge Category', 'twentytwenty' ),
        'update_item'                => __( 'Update knowledge Category', 'twentytwenty' ),
        'add_new_item'               => __( 'Add New knowledge Category', 'twentytwenty' ),
        'new_item_name'              => __( 'New knowledge Category Name', 'twentytwenty' ),
        'separate_items_with_commas' => __( 'Separate knowledge category with commas', 'twentytwenty' ),
        'add_or_remove_items'        => __( 'Add or remove knowledge category', 'twentytwenty' ),
        'not_found'                  => __( 'No knowledge category found.', 'twentytwenty' ),
        'menu_name'                  => __( 'knowledge Category', 'twentytwenty' ),
    );
 
    $args_knwl_cat = array(
        'hierarchical'          => true,
        'labels'                => $lbl_knwl_cat,
        'show_ui'               => true,
        'show_admin_column'     => true,
        'update_count_callback' => '_update_post_term_count',
        'query_var'             => true,
        'rewrite'               => array( 'slug' => 'knowledge_cat' ),
    );
 
    register_taxonomy( 'knowledge_cat', 'knowledge', $args_knwl_cat );

    $lbl_knwltags_cat = array(
        'name'                       => _x( 'Filters', 'taxonomy general name', 'twentytwenty' ),
        'singular_name'              => _x( 'Filters', 'taxonomy singular name', 'twentytwenty' ),
        'search_items'               => __( 'Search Filters', 'twentytwenty' ),
        'popular_items'              => __( 'Popular Filters', 'twentytwenty' ),
        'all_items'                  => __( 'All Filters', 'twentytwenty' ),
        'parent_item'                => null,
        'parent_item_colon'          => null,
        'edit_item'                  => __( 'Edit Filters', 'twentytwenty' ),
        'update_item'                => __( 'Update Filters', 'twentytwenty' ),
        'add_new_item'               => __( 'Add New Filters', 'twentytwenty' ),
        'new_item_name'              => __( 'New Filters Name', 'twentytwenty' ),
        'separate_items_with_commas' => __( 'Separate filters with commas', 'twentytwenty' ),
        'add_or_remove_items'        => __( 'Add or remove filters', 'twentytwenty' ),
        'not_found'                  => __( 'No filters found.', 'twentytwenty' ),
        'menu_name'                  => __( 'Filters', 'twentytwenty' ),
    );
 
    $args_knwltags_cat = array(
        'hierarchical'          => true,
        'labels'                => $lbl_knwltags_cat,
        'show_ui'               => true,
        'show_admin_column'     => true,
        'update_count_callback' => '_update_post_term_count',
        'query_var'             => true,
        'rewrite'               => array( 'slug' => 'casestudy_filters' ),
    );
 
    register_taxonomy( 'casestudy_filters', 'knowledge', $args_knwltags_cat );

}
add_action( 'init', 'grod_resgister_post_init' );


function grod_show_permalinks( $post_link, $post ){
    if ( is_object( $post ) && $post->post_type == 'markets' ){
        $terms = wp_get_object_terms( $post->ID, 'markets_cat' );
        if( $terms ){
            return str_replace( '%markets_cat%' , $terms[0]->slug , $post_link );
        }
    }
    if ( is_object( $post ) && $post->post_type == 'solutions' ){
        $terms = wp_get_object_terms( $post->ID, 'solutions_cat' );
        if( $terms ){
            return str_replace( '%solutions_cat%' , $terms[0]->slug , $post_link );
        }
    }
    if ( is_object( $post ) && $post->post_type == 'products' ){
        $terms = wp_get_object_terms( $post->ID, 'products_cat' );
        if( $terms ){
            return str_replace( '%products_cat%' , $terms[0]->slug , $post_link );
        }
    }
    if ( is_object( $post ) && $post->post_type == 'knowledge' ){
        $terms = wp_get_object_terms( $post->ID, 'knowledge_cat' );
        if( $terms ){
            
            $post_link = trailingslashit( home_url('/knowledge/'. $terms[0]->slug . '/' . $post->post_name .'/' ) );
        }else
        {
             $post_link = trailingslashit( home_url('/knowledge/' . $post->post_name .'/' ) );
        }
    }
    return $post_link;
}
add_filter( 'post_type_link', 'grod_show_permalinks', 1, 2 );


/* Partner Logo Function */

function Partner_Logos_Fn($post_id)
{
    if(get_field("fbs_partner_slider",$post_id))
    {
        echo '<section class="footer-module horizontal-logos section">';
            echo '<div class="wrapper">';
                echo '<div class="inner">';
                    if(get_field("partner_add_logo_image",$post_id))
                    {
                        while (has_sub_field("partner_add_logo_image",$post_id)) {
                            $_p_logo = get_sub_field("part_upload_logo",$post_id);
                            if(!empty($_p_logo))
                            {
                                echo '<div class="logo">';
                                    echo '<img src="'.$_p_logo['url'].'" alt="'.$_p_logo['alt'].'" >';
                                echo '</div>';
                            }
                        }
                    }
                echo '</div>';
            echo '</div>';
        echo '</section>';
    }
}
function Contact_Form_Fn($post_id)
{
    if(get_field("fbs_contact_form",$post_id))
    {
        $bg_color = get_field("fbs_cfrm_bg_color",$post_id);
        echo '<section class="footer-module contact-form section bg-'.$bg_color.'">';
            echo '<div class="wrapper">';
                echo '<div class="content-section">';
                    echo get_field("fbs_cfrm_description",$post_id);
                echo '</div>';
                echo '<div class="contact-section">';
                    $gfrm = get_field("fbs_cfrm_shortcode",$post_id);
                    echo do_shortcode($gfrm);
                echo '</div>';
            echo '</div>';
        echo '</section>';
    }
}
?>