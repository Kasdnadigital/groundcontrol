<?php
/**
 * The Template for displaying product archives, including the main shop page which is a post type archive
 *
 * This template can be overridden by copying it to yourtheme/woocommerce/archive-product.php.
 *
 * HOWEVER, on occasion WooCommerce will need to update template files and you
 * (the theme developer) will need to copy the new files to your theme to
 * maintain compatibility. We try to do this as little as possible, but it does
 * happen. When this occurs the version of the template file will be bumped and
 * the readme will list any important changes.
 *
 * @see https://docs.woocommerce.com/document/template-structure/
 * @package WooCommerce\Templates
 * @version 3.4.0
 */

defined( 'ABSPATH' ) || exit;

get_header();

//echo '<input type="hidden" class="admin_url" value="'.admin_url('admin-ajax.php').'">';

// Get Taxonomy vars
$queried_object = get_queried_object(); 
$gc_prd_tax = $queried_object->taxonomy;
$gc_prd_tax_term_id = $queried_object->term_id;
$tax_name = str_replace('product_', '', $gc_prd_tax);


$bnr_img = "";
$gc_prd_tax_bnrimg = get_field('gc_prd_tax_bnrimg', $gc_prd_tax . '_' . $gc_prd_tax_term_id);
if ($gc_prd_tax_bnrimg != "") {
    $bnr_img = $gc_prd_tax_bnrimg;
} /*else if (is_shop()) {
    $bnr_img = site_url()."/wp-content/uploads/2022/01/Sata-Comms-Final-Reversed.webp";
}*/ else {
    $bnr_img = site_url()."/wp-content/uploads/2022/01/Sata-Comms-Final-Reversed.webp";
} ?>

<div class="archive-hero section" style="background-image:url(<?php echo $bnr_img; ?>)">
    <div class="wrapper">
        <div class="content-wrapper">
            <?php
            if ($gc_prd_tax != 'product_cat') { ?><h6><?php echo $tax_name; ?></h6> <?php } ?>
            <h1><?php echo single_cat_title(); ?></h1>
        </div>
    </div>
</div>

<div class="wrapper">
<?php

if ( woocommerce_product_loop() ) {

    /**
     * Hook: woocommerce_before_shop_loop.
     *
     * @hooked woocommerce_output_all_notices - 10
     * @hooked woocommerce_result_count - 20
     * @hooked woocommerce_catalog_ordering - 30
     */
    do_action( 'woocommerce_before_shop_loop' ); ?>


    <select name="orderby" id="gc_custom_prod_sort" class="gc_custom_prod_sort" data-current-taxonomy="<?php echo $gc_prd_tax; ?>" data-current-termid="<?php echo $gc_prd_tax_term_id; ?>">
        <option value="menu_order">Default sorting</option>
        <option value="popularity">Sort by popularity</option>
        <option value="rating">Sort by average rating</option>
        <option value="date">Sort by latest</option>
        <option value="price">Sort by price: low to high</option>
        <option value="price-desc">Sort by price: high to low</option>
    </select>

    
    <?php



    woocommerce_product_loop_start();

    if ( wc_get_loop_prop( 'total' ) ) {
        while ( have_posts() ) {
            the_post();

            /**
             * Hook: woocommerce_shop_loop.
             */
            do_action( 'woocommerce_shop_loop' );

            wc_get_template_part( 'content', 'product' );
        }
    }

    woocommerce_product_loop_end();

    /**
     * Hook: woocommerce_after_shop_loop.
     *
     * @hooked woocommerce_pagination - 10
     */
    do_action( 'woocommerce_after_shop_loop' );
} else {
    /**
     * Hook: woocommerce_no_products_found.
     *
     * @hooked wc_no_products_found - 10
     */
    do_action( 'woocommerce_no_products_found' );
}

/**
 * Hook: woocommerce_after_main_content.
 *
 * @hooked woocommerce_output_content_wrapper_end - 10 (outputs closing divs for the content)
 */
//do_action( 'woocommerce_after_main_content' );

/**
 * Hook: woocommerce_sidebar.
 *
 * @hooked woocommerce_get_sidebar - 10
 */
//do_action( 'woocommerce_sidebar' );
?>
</div>
<script type="text/javascript">
    //function getCaseStusdy(page) 
      //{
    jQuery(document).ready(function($) {
        //$("#gc_custom_prod_sort option:first").attr('selected','selected');
        //$('select.gc_custom_prod_sort').find('option[value=date]').attr('selected','selected');
        //jQuery('body').on('change', '.gc_custom_prod_sort', function() {
        $( ".gc_custom_prod_sort" ).change(function() {
            
            //var sorting_opt = $(this).val();
            var sorting_opt = $('.gc_custom_prod_sort').val();
            var current_taxonomy = $(this).data("current-taxonomy");
            var current_termid = $(this).data("current-termid");

            var ajax_url = '<?php echo admin_url('admin-ajax.php'); ?>';
                jQuery.ajax({    
                    type: "POST", 
                    url: ajax_url,
                    data: {
                        action: 'prod_sorting_via_ajax',
                        'sorting_opt': sorting_opt,
                        'current_taxonomy' : current_taxonomy,
                        'current_termid' : current_termid,
                    },

                    success: function (data) {
                        console.log(data);
                        //console.log("data");
                        //jQuery(".load_html").html(data);
                    },
                });
        });
    });
      //}
</script>
<?php get_footer(); ?>