jQuery( document ).ready(function() {

  var t_filter   = '';
  function getCaseStusdy(page) 
  {
    var ajax_url = jQuery('.admin_url').val();
      jQuery.ajax({    
      type: "POST", 
      url: ajax_url,
      data: {
        action: 'casestudy_post_ajax_callback',
        page: page,
        t_filter: t_filter,
      },          
      success: function (response) {
        if(response.success){
          jQuery('.studies-container').html(response.data.html).fadeIn();
          jQuery('.pagination-inner').html(response.data.pagination).fadeIn();
          if(response.data.sel_terms_data != '')
          {
            jQuery(".title-holder .subtitle").html(response.data.sel_terms_data);
          }
        }
      },
    });
  }

  jQuery(document).on('click','.pagination-inner a',function(e){
    var page = jQuery(this).data('page');
    getCaseStusdy(page);
  });

  jQuery(document).on('click','.filters-container.filters-open a',function(e){
    t_filter = jQuery(this).attr('id');
    jQuery(".filters-container").removeClass("filters-open")
    getCaseStusdy(1);
  });

  setTimeout(() => {
    getCaseStusdy(1);
  }, 2000);

  jQuery(".lower-menu h2 .arrow").click(function(){
      if(jQuery(this).next(".submenu").is(":visible")){
        jQuery(this).next(".submenu").slideUp();
        jQuery("h2").removeClass("active");
      }
      else
      {
        jQuery(".lower-menu h2").removeClass("active");
        jQuery(this).parent("h2").addClass("active");
        jQuery(".lower-menu h2 .submenu").slideUp();
        jQuery(this).next(".submenu").slideDown();
      }
  });

  jQuery('.mobile-trigger').click(function(){
    jQuery("body").toggleClass('menu-open');
  });
  
  jQuery('body.blog .template-inner .posts a.single-post').matchHeight();
  
});