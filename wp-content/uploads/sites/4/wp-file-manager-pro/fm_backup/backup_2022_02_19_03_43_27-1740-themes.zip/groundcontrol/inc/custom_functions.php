<?php 
// Adding Theme  Options to Custom Fields Options
function grod_acf_options_page_settings($settings) {
    $settings['title'] = __('Theme Option','acf');
    $settings['menu'] = __('Theme Option','acf');
    $settings['pages'] = array('General Setting');

    return $settings;
}
add_filter('acf/options_page/settings', 'grod_acf_options_page_settings');

function grod_resgister_post_init() {
   
   /* Market Custom Post Type */ 

    $lbl_mkt = array(
        'name'                  => _x( 'Markets Pages', 'Post type general name', 'twentytwenty' ),
        'singular_name'         => _x( 'Market', 'Post type singular name', 'twentytwenty' ),
        'menu_name'             => _x( 'Markets Pages', 'Admin Menu text', 'twentytwenty' ),
        'name_admin_bar'        => _x( 'Markets', 'Add New on Toolbar', 'twentytwenty' ),
        'add_new'               => __( 'Add New', 'twentytwenty' ),
        'add_new_item'          => __( 'Add New Market', 'twentytwenty' ),
        'new_item'              => __( 'New Market', 'twentytwenty' ),
        'edit_item'             => __( 'Edit Market', 'twentytwenty' ),
        'view_item'             => __( 'View Market', 'twentytwenty' ),
        'all_items'             => __( 'All Market', 'twentytwenty' ),
        'search_items'          => __( 'Search Markets', 'twentytwenty' ),
        'parent_item_colon'     => __( 'Parent Markets:', 'twentytwenty' ),
        'not_found'             => __( 'No markets found.', 'twentytwenty' ),
        'not_found_in_trash'    => __( 'No markets found in Trash.', 'twentytwenty' ),
       
    );     
    $args_mkt = array(
        'labels'             => $lbl_mkt,
        'description'        => 'Markets',
        'public'             => true,
        'publicly_queryable' => true,
        'show_ui'            => true,
        'show_in_menu'       => true,
        'query_var'          => true,
        'rewrite'            => array( 'slug' => 'markets' ),
        'capability_type'    => 'post',
        'has_archive'        => false,
        'hierarchical'       => true,
        'menu_position'      => 20,
        'supports'           => array( 'title', 'editor', 'author', 'thumbnail' ,'page-attributes'),
        'show_in_rest'       => true
    );
      
    register_post_type( 'markets', $args_mkt );

   

    /* Solutions Custom Post Type */ 
    $lbl_sol = array(
        'name'                  => _x( 'Solutions Pages', 'Post type general name', 'twentytwenty' ),
        'singular_name'         => _x( 'Solution', 'Post type singular name', 'twentytwenty' ),
        'menu_name'             => _x( 'Solutions Pages', 'Admin Menu text', 'twentytwenty' ),
        'name_admin_bar'        => _x( 'Solutions', 'Add New on Toolbar', 'twentytwenty' ),
        'add_new'               => __( 'Add New', 'twentytwenty' ),
        'add_new_item'          => __( 'Add New Solution', 'twentytwenty' ),
        'new_item'              => __( 'New Solution', 'twentytwenty' ),
        'edit_item'             => __( 'Edit Solution', 'twentytwenty' ),
        'view_item'             => __( 'View Solution', 'twentytwenty' ),
        'all_items'             => __( 'All Solution', 'twentytwenty' ),
        'search_items'          => __( 'Search Solution', 'twentytwenty' ),
        'parent_item_colon'     => __( 'Parent Solution:', 'twentytwenty' ),
        'not_found'             => __( 'No solutions found.', 'twentytwenty' ),
        'not_found_in_trash'    => __( 'No solutions found in Trash.', 'twentytwenty' ),
       
    );     
    $args_sol = array(
        'labels'             => $lbl_sol,
        'description'        => 'Solutions',
        'public'             => true,
        'publicly_queryable' => true,
        'show_ui'            => true,
        'show_in_menu'       => true,
        'query_var'          => true,
        'rewrite'            => array( 'slug' => 'solutions' ),
        'capability_type'    => 'post',
        'has_archive'        => false,
        'hierarchical'       => true,
        'menu_position'      => 20,
        'supports'           => array( 'title', 'editor', 'author', 'thumbnail','page-attributes' ),
        'show_in_rest'       => true
    );
      
    register_post_type( 'solutions', $args_sol );




    /* Products Custom Post Type */ 

    $lbl_prod = array(
        'name'                  => _x( 'Products Pages', 'Post type general name', 'twentytwenty' ),
        'singular_name'         => _x( 'Products', 'Post type singular name', 'twentytwenty' ),
        'menu_name'             => _x( 'Products Pages', 'Admin Menu text', 'twentytwenty' ),
        'name_admin_bar'        => _x( 'Products', 'Add New on Toolbar', 'twentytwenty' ),
        'add_new'               => __( 'Add New', 'twentytwenty' ),
        'add_new_item'          => __( 'Add New Products', 'twentytwenty' ),
        'new_item'              => __( 'New Products', 'twentytwenty' ),
        'edit_item'             => __( 'Edit Products', 'twentytwenty' ),
        'view_item'             => __( 'View Products', 'twentytwenty' ),
        'all_items'             => __( 'All Products', 'twentytwenty' ),
        'search_items'          => __( 'Search Products', 'twentytwenty' ),
        'parent_item_colon'     => __( 'Parent Products:', 'twentytwenty' ),
        'not_found'             => __( 'No Products found.', 'twentytwenty' ),
        'not_found_in_trash'    => __( 'No Products found in Trash.', 'twentytwenty' ),
       
    );     
    $args_prod = array(
        'labels'             => $lbl_prod,
        'description'        => 'Products',
        'public'             => true,
        'publicly_queryable' => true,
        'show_ui'            => true,
        'show_in_menu'       => true,
        'query_var'          => true,
        'rewrite'            => array( 'slug' => 'products' ),
        'capability_type'    => 'post',
        'has_archive'        => false,
        'hierarchical'       => true,
        'menu_position'      => 20,
        'supports'           => array( 'title', 'editor', 'author', 'thumbnail','page-attributes','excerpt' ),
        'show_in_rest'       => true
    );
      
    register_post_type( 'products', $args_prod );

    /* Knowledge Custom Post Type */
    $lbl_knwl = array(
        'name'                  => _x( 'Knowledge Pages', 'Post type general name', 'twentytwenty' ),
        'singular_name'         => _x( 'Knowledge', 'Post type singular name', 'twentytwenty' ),
        'menu_name'             => _x( 'Knowledge Pages', 'Admin Menu text', 'twentytwenty' ),
        'name_admin_bar'        => _x( 'Knowledge', 'Add New on Toolbar', 'twentytwenty' ),
        'add_new'               => __( 'Add Knowledge', 'twentytwenty' ),
        'add_new_item'          => __( 'Add New Knowledge', 'twentytwenty' ),
        'new_item'              => __( 'New Knowledge', 'twentytwenty' ),
        'edit_item'             => __( 'Edit Knowledge', 'twentytwenty' ),
        'view_item'             => __( 'View Knowledge', 'twentytwenty' ),
        'all_items'             => __( 'All Knowledge', 'twentytwenty' ),
        'search_items'          => __( 'Search Knowledge', 'twentytwenty' ),
        'parent_item_colon'     => __( 'Parent Knowledge:', 'twentytwenty' ),
        'not_found'             => __( 'No knowledge found.', 'twentytwenty' ),
        'not_found_in_trash'    => __( 'No knowledge found in Trash.', 'twentytwenty' ),
       
    );     
    $args_knwl = array(
        'labels'             => $lbl_knwl,
        'description'        => 'Knowledge',
        'public'             => true,
        'publicly_queryable' => true,
        'show_ui'            => true,
        'show_in_menu'       => true,
        'query_var'          => true,
        'rewrite'            => array( 'slug' => 'knowledge' ),
        'capability_type'    => 'post',
        'has_archive'        => false,
        'hierarchical'       => true,
        'menu_position'      => 20,
        'supports'           => array( 'title', 'editor', 'author', 'thumbnail','page-attributes','excerpt' ),
        'show_in_rest'       => true
    );
      
    register_post_type( 'knowledge', $args_knwl );

    $lbl_knwl_cat = array(
        'name'                       => _x( 'knowledge Category', 'taxonomy general name', 'twentytwenty' ),
        'singular_name'              => _x( 'knowledge Category', 'taxonomy singular name', 'twentytwenty' ),
        'search_items'               => __( 'Search knowledge Category', 'twentytwenty' ),
        'popular_items'              => __( 'Popular knowledge Category', 'twentytwenty' ),
        'all_items'                  => __( 'All knowledge Category', 'twentytwenty' ),
        'parent_item'                => null,
        'parent_item_colon'          => null,
        'edit_item'                  => __( 'Edit knowledge Category', 'twentytwenty' ),
        'update_item'                => __( 'Update knowledge Category', 'twentytwenty' ),
        'add_new_item'               => __( 'Add New knowledge Category', 'twentytwenty' ),
        'new_item_name'              => __( 'New knowledge Category Name', 'twentytwenty' ),
        'separate_items_with_commas' => __( 'Separate knowledge category with commas', 'twentytwenty' ),
        'add_or_remove_items'        => __( 'Add or remove knowledge category', 'twentytwenty' ),
        'not_found'                  => __( 'No knowledge category found.', 'twentytwenty' ),
        'menu_name'                  => __( 'knowledge Category', 'twentytwenty' ),
    );
 
    $args_knwl_cat = array(
        'hierarchical'          => true,
        'labels'                => $lbl_knwl_cat,
        'show_ui'               => true,
        'show_admin_column'     => true,
        'update_count_callback' => '_update_post_term_count',
        'query_var'             => true,
        'rewrite'               => array( 'slug' => 'knowledge_cat' ),
    );
 
    register_taxonomy( 'knowledge_cat', 'knowledge', $args_knwl_cat );

    $lbl_knwltags_cat = array(
        'name'                       => _x( 'Filters', 'taxonomy general name', 'twentytwenty' ),
        'singular_name'              => _x( 'Filters', 'taxonomy singular name', 'twentytwenty' ),
        'search_items'               => __( 'Search Filters', 'twentytwenty' ),
        'popular_items'              => __( 'Popular Filters', 'twentytwenty' ),
        'all_items'                  => __( 'All Filters', 'twentytwenty' ),
        'parent_item'                => null,
        'parent_item_colon'          => null,
        'edit_item'                  => __( 'Edit Filters', 'twentytwenty' ),
        'update_item'                => __( 'Update Filters', 'twentytwenty' ),
        'add_new_item'               => __( 'Add New Filters', 'twentytwenty' ),
        'new_item_name'              => __( 'New Filters Name', 'twentytwenty' ),
        'separate_items_with_commas' => __( 'Separate filters with commas', 'twentytwenty' ),
        'add_or_remove_items'        => __( 'Add or remove filters', 'twentytwenty' ),
        'not_found'                  => __( 'No filters found.', 'twentytwenty' ),
        'menu_name'                  => __( 'Filters', 'twentytwenty' ),
    );
 
    $args_knwltags_cat = array(
        'hierarchical'          => true,
        'labels'                => $lbl_knwltags_cat,
        'show_ui'               => true,
        'show_admin_column'     => true,
        'update_count_callback' => '_update_post_term_count',
        'query_var'             => true,
        'rewrite'               => array( 'slug' => 'casestudy_filters' ),
    );
 
    register_taxonomy( 'casestudy_filters', 'knowledge', $args_knwltags_cat );

}
add_action( 'init', 'grod_resgister_post_init' );


function grod_show_permalinks( $post_link, $post ){
    
   
    
    if ( is_object( $post ) && $post->post_type == 'knowledge' ){
        $terms = wp_get_object_terms( $post->ID, 'knowledge_cat' );
        if( $terms ){
            
            $post_link = trailingslashit( home_url('/knowledge/'. $terms[0]->slug . '/' . $post->post_name .'/' ) );
        }else
        {
             $post_link = trailingslashit( home_url('/knowledge/' . $post->post_name .'/' ) );
        }
    }
    return $post_link;
}
add_filter( 'post_type_link', 'grod_show_permalinks', 1, 2 );


/* Partner Logo Function */

function Partner_Logos_Fn($post_id)
{
    if(get_field("fbs_partner_slider",$post_id))
    {
        echo '<section class="footer-module horizontal-logos section">';
            echo '<div class="wrapper">';
                echo '<div class="inner">';
                    if(get_field("partner_add_logo_image",$post_id))
                    {
                        while (has_sub_field("partner_add_logo_image",$post_id)) {
                            $_p_logo = get_sub_field("part_upload_logo",$post_id);
                            if(!empty($_p_logo))
                            {
                                echo '<div class="logo">';
                                    echo '<img src="'.$_p_logo['url'].'" alt="'.$_p_logo['alt'].'" >';
                                echo '</div>';
                            }
                        }
                    }
                echo '</div>';
            echo '</div>';
        echo '</section>';
    }
}
function Contact_Form_Fn($post_id)
{
    if(get_field("fbs_contact_form",$post_id))
    {
        $bg_color = get_field("fbs_cfrm_bg_color",$post_id);
        echo '<section class="footer-module contact-form section bg-'.$bg_color.'">';
            echo '<div class="wrapper">';
                echo '<div class="content-section">';
                    echo get_field("fbs_cfrm_description",$post_id);
                echo '</div>';
                echo '<div class="contact-section">';
                    $gfrm = get_field("fbs_cfrm_shortcode",$post_id);
                    echo do_shortcode($gfrm);
                echo '</div>';
            echo '</div>';
        echo '</section>';
    }
}


add_action('wp_ajax_casestudy_post_ajax_callback', 'casestudy_post_ajax_callback');
add_action('wp_ajax_nopriv_casestudy_post_ajax_callback', 'casestudy_post_ajax_callback');

function casestudy_post_ajax_callback(){
    $paged      = $_POST['page'];
    if($_POST['t_filter'] != '')
    {
        $case_query  = new WP_Query( array(
            'post_type'      => 'knowledge',
            'posts_per_page' => 4,
            'paged'          => $paged,
            'tax_query' => array(
                array(
                    'taxonomy' => 'casestudy_filters',
                    'field'    => 'term_id',
                    'terms'    => $_POST['t_filter'],
                ),
            ),
        ));
    }else
    {
        $case_query  = new WP_Query( array(
            'post_type'      => 'knowledge',
            'posts_per_page' => 4,
            'paged'          => $paged,
            'tax_query' => array(
                array(
                    'taxonomy' => 'knowledge_cat',
                    'field'    => 'slug',
                    'terms'    => 'case-study',
                ),
            ),
        ));
    } 
    


    $html       = '';
    $sel_terms_data = '';

    if ( $case_query->have_posts() ) { 

        while ( $case_query->have_posts() ) {  $case_query->the_post();
            $html .= '<div class="single-case-study">';     
               $html .= '<a href="'.get_the_permalink().'">';
                    $html .= '<div class="image-container section">';
                        $html .= '<img src="'.get_the_post_thumbnail_url(get_the_ID(),'full').'" />';
                    $html .= '</div>';
                    $html .= '<div class="content-container section">';
                        $html .= '<h5 data-mh="card-titles" class="date uppercase section">Case Study</h5>';
                        $html .= '<h4 class="post-title section">'.get_the_title().'</h4>';
                        $html .= '<p data-mh="card-excerpts" class="section">'.get_the_excerpt().'</p>';
                    $html .= '</div>';
               $html .= '</a>';    
            $html .= '</div>';   
        }
    }else{
            $html .= '<h3>data not found</h3>';
    } wp_reset_postdata();

    if($_POST['t_filter'] != '')
    {
        $terms_name = get_term_by('id',$_POST['t_filter'], 'casestudy_filters');
        $sel_terms_data = $terms_name->name;
    }
    $numer_of_pages = $case_query->max_num_pages;
    if($paged > 1) {
        $prev_page = $paged - 1;
        $pagination .= '<a class="prev page-numbers" data-page="'. $prev_page .'">« Previous</a>';
    }
    
    for ($i = 1; $i <= $numer_of_pages; $i++) {
        if( $paged == $i ) {
            $pagination .= '<span aria-current="page" class="page-numbers current">'. $i .'</span>';
        } else {
            $pagination .= '<a class="page-numbers" data-page="'.$i.'">'. $i .'</a>';
        }
    }
    
    if($paged != $numer_of_pages) {
        $next_page = $paged + 1;
        $pagination .= '<a class="next page-numbers" data-page="'. $next_page .'">Next »</a>';
    }

    $response_data = ['html' => $html, 'pagination' => $pagination, 'sel_terms_data' => $sel_terms_data];
    wp_send_json_success($response_data);
    die();
}
?>